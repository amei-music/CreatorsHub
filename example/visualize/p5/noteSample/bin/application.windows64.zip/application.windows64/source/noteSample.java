import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import oscP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class noteSample extends PApplet {

/**
* Example for mw1
* Need oscP5
*/


OscP5 oscP5;
int PORT = 24080;
CirclePrimitive[] circles;
int index = 0;
int brightness = 0;
int[] lastNote = {0,0,0};
int[] lastCC = {0,0,0};

public void setup() {
  
  oscP5 = new OscP5(this, PORT);
  circles = new CirclePrimitive[100];
  for (int i = 0; i < circles.length; ++i) {
    circles[i] = new CirclePrimitive();
  }
}

public void draw() {
  background(brightness);
  blendMode(ADD);

  drawInfo();

  CirclePrimitive cc = new CirclePrimitive();
  cc.update();
  for (CirclePrimitive c : circles) {
    c.update();
  }

  for (CirclePrimitive c : circles) {
    c.draw();
  }
}


public void oscEvent(OscMessage theOscMessage){
  if (theOscMessage.checkAddrPattern("/midi/noteon") == true) {
    int ch = (int)theOscMessage.get(0).floatValue();
    int noteNum = (int)theOscMessage.get(1).floatValue();
    int velocity = (int)theOscMessage.get(2).floatValue();
    noteOn(ch, noteNum, velocity);
    lastNote[0] = ch;
    lastNote[1] = noteNum;
    lastNote[2] = velocity;
  } else if (theOscMessage.checkAddrPattern("/midi/controlchange") == true) {
    int ch = (int)theOscMessage.get(0).floatValue();
    int controlNum = (int)theOscMessage.get(1).floatValue();
    int value = (int)theOscMessage.get(2).floatValue();
    controlChange(ch, controlNum, value);
    lastCC[0] = ch;
    lastCC[1] = controlNum;
    lastCC[2] = value;
  }
}

public void noteOn(int ch, int noteNum, int velocity) {
  CirclePrimitive circle = circles[index];
  float x = noteNum / 128.0f * width;
  float y = height - (velocity / 128.0f * height);
  circle.setPosition(x, y);
  
  colorMode(HSB, 128, 128, 128);
  int c = color(noteNum, velocity, 128);
  circle.setColor(c);
  
  float radius = velocity + 10;
  circle.setRadius(radius);
  
  incrementIndex();
}

public void controlChange(int ch, int controlNum, int value) {
  brightness = (int)map(value, 0, 127, 0, 100);
  println(brightness);
}

public void incrementIndex() {
  ++index;
  if (index >= circles.length) {
    index = 0;
  }
}

public void drawInfo() {
  String portinfo =  "OSC receive port="+ str(PORT);
  String noteinfo = "Latest Note#" + lastNote[1] + "[" + lastNote[2] + "] ch" + lastNote[0]; 
  String ccinfo = "Latest CC#" + lastCC[1] + "[" + lastCC[2] + "] ch" + lastCC[0]; 
  fill(100);
  text(portinfo, 10, 15);
  text(noteinfo, 10, 30);
  text(ccinfo, 10, 45);
}
class CirclePrimitive {
  PVector pos;
  float radius;
  int col;
  
  CirclePrimitive() {
    pos = new PVector(0, 0);
    radius = 0;
  }
  
  CirclePrimitive(float x, float y) {
    pos = new PVector(x, y);
    radius = 0;
  }
  
  public void setRadius(float rad) {
    radius = rad;
  }
  
  public void setPosition(float x, float y) {
    pos.x = x;
    pos.y = y;
  }
  
  public void setColor(int c) {
    col = c;
  }
  
  public void update() {
    float target = 0.0f;
    radius = (radius - target) / 1.1f;
  }
  
  public void draw() {
    noStroke();
    fill(col);
    ellipse(pos.x, pos.y, radius, radius);
    if (radius > 1) {
      println(pos.x + " " + pos.y + " " + radius);
    }
  }
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "noteSample" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
