import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import oscP5.*; 
import netP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class oscSequencer extends PApplet {




OscP5 oscP5;
int MY_PORT = 24082;
int SEND_PORT = 24081;
float bpm = 60;
NetAddress remote;

Tile[][] sequences = new Tile[3][16];
int noteNums[] = {64, 62, 60};
int velocities[] = {100, 100, 100};
float startx;
float endx;
float startsec;
float liney;
float linelen;
float startmsec;
float prevlinex = 0.0f;

int lastNote = 0;

public void setup() {
  

  // initialize
  oscP5 = new OscP5(this, MY_PORT);  
  remote = new NetAddress("localhost", SEND_PORT);
  for (int i = 0; i < sequences.length; ++i) {
    for (int j = 0; j < sequences[i].length; ++j) {
      sequences[i][j] = new Tile();
    }
  }

  // position
  initPosition();

  startmsec = millis();
}

public void update() {
  for (int i = 0; i < sequences.length; ++i) {
    for (int j = 0; j < sequences[i].length; ++j) {
      sequences[i][j].update();
    }
  }
}

public void draw() {
  update();
  
  background(180);

  float elapsed = (millis() - startmsec) / 1000.0f;
  float sec_per_beat = 60.f/bpm;
  float totaltime = sequences[0].length * sec_per_beat / 4.0f;
  float rate = elapsed % totaltime / totaltime;
  float linex = (endx - startx) * rate + startx;

  for (int i = 0; i < sequences.length; ++i) {
    for (int j = 0; j < sequences[i].length; ++j) {
      float x = sequences[i][j].getPosition().x;
      if ((x <= linex && x >= prevlinex)
        || (prevlinex > linex && x <= linex)) {
        if (sequences[i][j].isOn()) {
          sequences[i][j].emit();
          sendNoteOn(0, noteNums[i], velocities[i]);
        }
      }

      float x2 = x + sequences[i][j].getSize();
      if ((x2 <= linex && x2 >= prevlinex)
        || (prevlinex > linex && x2 <= linex)) {
        if (sequences[i][j].isOn()) {
          sendNoteOff(0, noteNums[i], velocities[i]);
        }
      }
      sequences[i][j].draw();
    }
  }

  stroke(200, 0, 0);
  line(linex, liney, linex, liney + linelen);

  prevlinex = linex;
  
  drawInfo();
}

public void initPosition() {
  float len = width / 24;
  float grid = 1.0f;
  float hmargin = (width - (len * sequences[0].length + grid * (sequences[0].length-1))) / 2.0f;
  float vmargin = (height -  len * 5 - grid * 4)/2.0f;
  for (int vindex = 0; vindex < sequences.length; ++vindex) {
    for (int hindex = 0; hindex < sequences[vindex].length; ++hindex) {
      float x = hindex * (len + grid) + hmargin;
      float y = vmargin + (len + grid)* vindex; 
      sequences[vindex][hindex].setPosition((int)x, (int)y);
      sequences[vindex][hindex].setSize((int)len);
    }
  }
  startx = hmargin;
  endx = hmargin + len * sequences[0].length + (grid * sequences[0].length-1);
  liney = vmargin;
  linelen = len * 3 + grid * 2;
}

public void sendNoteOn(int ch, int noteNum, int velocity) {
  //println("note on");
  OscMessage noteOn = new OscMessage("/midi/noteon");
  noteOn.add(ch);
  noteOn.add(noteNum);
  noteOn.add(velocity);
  oscP5.send(noteOn, remote);
  
  lastNote = noteNum;
}

public void sendNoteOff(int ch, int noteNum, int velocity) {
  //println("note off");
  OscMessage noteOff = new OscMessage("/midi/noteoff");
  noteOff.add(ch);
  noteOff.add(noteNum);
  noteOff.add(velocity);
  oscP5.send(noteOff, remote);
}

public void mousePressed() {
  for (int i = 0; i < sequences.length; ++i) {
    for (int j = 0; j < sequences[i].length; ++j) {
      sequences[i][j].isClicked(mouseX, mouseY);
    }
  }
}

public void drawInfo() {
  String portinfo =  "OSC Send Port="+ str(SEND_PORT);
  String noteinfo = "Latest Sent Note#" + lastNote; 
  fill(0);
  text(portinfo, 10, 15);
  text(noteinfo, 10, 30);
}
class Tile {
  PVector pos;
  int len;
  int col;
  boolean isOn = false;
  
  int onColor = color(120,120,120);
  int offColor = color(20,20,20);
  int emitColor = color(200,0,0);
  
  Tile() {
    pos = new PVector(0, 0);
    len = 10;
    col = offColor;
  }
  
  public void setPosition(int x, int y) {
    pos.x = x;
    pos.y = y;
  }
  
  public PVector getPosition() {
    return pos;
  }
  
  public void setSize(int size) {
    len = size;
  }
  
  public int getSize() {
    return len;
  }
  
  public void update() {
    int target;
    if (isOn) {
        target = onColor;
    } else {
        target = offColor;
    }

    float r = red(col) + (red(target) - red(col)) * 0.1f;
    float g = green(col) + (green(target) - green(col)) * 0.1f;
    float b = blue(col) + (blue(target) - blue(col)) * 0.1f;

    col = color(r,g,b);
  }
  
  public void draw() {
    noStroke();
    fill(col);
    rect(pos.x, pos.y , len, len);
  }
  
  public void emit() {
    col = emitColor;
  }
  
  public boolean isClicked(int x, int y) {
    if (x >= pos.x && x <= (pos.x + len)
    && y >= pos.y && y <= (pos.y + len)) {
      isOn = !isOn;
      if(isOn) {
        col = onColor;
      } else {
        col = offColor;
      }
      return true;
    } else {
      return false;
    }
  }
  
  public boolean isOn() {
    return isOn;
  }
  public void isOn(boolean ison) {
    isOn = ison;
  }
  
}
  public void settings() {  size(800, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "oscSequencer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
